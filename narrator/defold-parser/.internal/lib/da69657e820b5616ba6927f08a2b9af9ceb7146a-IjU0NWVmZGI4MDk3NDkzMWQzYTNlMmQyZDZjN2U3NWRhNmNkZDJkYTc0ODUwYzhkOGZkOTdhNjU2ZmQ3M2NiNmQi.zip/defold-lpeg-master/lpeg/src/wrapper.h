/*
** LPeg extension for the Defold game engine
** https://github.com/astrochili/defold-lpeg
*/

#include "lpeg/lptree.h"

int luaopen_lpeg (lua_State *L);