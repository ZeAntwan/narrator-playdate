/*
** LPeg extension for the Defold game engine
** https://github.com/astrochili/defold-lpeg
**
** Placeholder for the lua.h that required by LPeg.
*/

#include <dmsdk/sdk.h>